import { CloudOff, LocateFixed, Search } from 'lucide-react';

export function Welcome({ onSearch, onLocate, locating }: { onSearch: () => void; onLocate: () => void; locating: boolean }) {
  return (
    <section className="empty rise">
      <p className="eyebrow">SkyCast</p>
      <h1>The weather,<br /><em>anywhere.</em></h1>
      <p className="lead">Live conditions, hourly detail and a seven-day outlook for any city on Earth.</p>
      <div className="empty-actions">
        <button type="button" className="btn primary" onClick={onSearch}><Search size={18} strokeWidth={1.8} /> Search a city</button>
        <button type="button" className="btn" onClick={onLocate} disabled={locating}><LocateFixed size={18} strokeWidth={1.8} /> {locating ? 'Locating…' : 'Use my location'}</button>
      </div>
    </section>
  );
}

export function ErrorState({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <section className="empty rise" role="alert">
      <CloudOff size={44} strokeWidth={1.3} />
      <h1 className="small">Weather unavailable</h1>
      <p className="lead">{message}</p>
      <div className="empty-actions"><button type="button" className="btn primary" onClick={onRetry}>Try again</button></div>
    </section>
  );
}

export function Skeletons() {
  return (
    <div aria-busy="true" aria-label="Loading weather">
      <div className="hero"><div className="skel" style={{ width: 220, height: 34 }} /><div className="skel" style={{ width: 160, height: 16, marginTop: 12 }} />
        <div className="skel" style={{ width: 'min(340px,80%)', height: 'clamp(110px,22vw,190px)', marginTop: 28, borderRadius: 32 }} /></div>
      <div className="card glass"><div className="skel" style={{ height: 120 }} /></div>
      <div className="card glass"><div className="skel" style={{ height: 300 }} /></div>
      <div className="metrics">{Array.from({ length: 4 }, (_, i) => <div key={i} className="tile glass"><div className="skel" style={{ height: 90 }} /></div>)}</div>
    </div>
  );
}
