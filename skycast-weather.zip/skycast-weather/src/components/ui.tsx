import { cssVars } from '../lib/css';
import type { ReactNode } from 'react';

export function IconButton({ label, onClick, children, active, disabled, className = '' }: {
  label: string; onClick?: () => void; children: ReactNode; active?: boolean; disabled?: boolean; className?: string;
}) {
  return (
    <button type="button" className={`iconbtn tip ${active ? 'on' : ''} ${className}`} data-tip={label} aria-label={label} onClick={onClick} disabled={disabled}>
      {children}
    </button>
  );
}

export function Segmented<T extends string>({ value, options, onChange, label }: {
  value: T; options: { value: T; label: string }[]; onChange: (v: T) => void; label: string;
}) {
  const i = Math.max(0, options.findIndex(o => o.value === value));
  return (
    <div className="seg" role="radiogroup" aria-label={label} style={cssVars({ '--n': options.length, '--i': i })}>
      <span className="seg-thumb" aria-hidden />
      {options.map(o => (
        <button key={o.value} type="button" role="radio" aria-checked={o.value === value} onClick={() => onChange(o.value)}>{o.label}</button>
      ))}
    </div>
  );
}

export function Switch({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return <button type="button" role="switch" aria-checked={checked} aria-label={label} className="switch" onClick={() => onChange(!checked)}><span /></button>;
}
