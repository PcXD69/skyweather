import { useEffect, useRef } from 'react';

interface Props {
  kind: 'rain' | 'snow' | 'none'; power: number; wind: number; windDir: number;
  dark: boolean; motes: boolean; low: boolean; reduced: boolean;
}
interface P { x: number; y: number; z: number; v: number; ph: number }

/** One lightweight canvas for rain, snow, wind streaks and floating light particles. */
export function Particles({ kind, power, wind, windDir, dark, motes, low, reduced }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const c = ref.current;
    const ctx = c?.getContext('2d');
    if (!c || !ctx || reduced) { ctx?.clearRect(0, 0, c?.width ?? 0, c?.height ?? 0); return; }

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const weak = low || (navigator.hardwareConcurrency || 8) <= 4 || window.innerWidth < 640;
    const k = weak ? 0.55 : 1;
    const s = -Math.sin((windDir * Math.PI) / 180);
    const dirX = Math.abs(s) < 0.25 ? (s < 0 ? -0.25 : 0.25) : s; // direction the wind blows towards
    const wf = Math.min(1, wind / 60);
    const mk = (n: number): P[] => Array.from({ length: Math.max(0, n) }, () => ({ x: Math.random(), y: Math.random(), z: Math.random(), v: Math.random(), ph: Math.random() * 6.28 }));
    const rain = mk(kind === 'rain' ? Math.round(320 * power * k) : 0);
    const snow = mk(kind === 'snow' ? Math.round(170 * power * k) : 0);
    const streaks = mk(wind >= 25 ? Math.round(26 * Math.min(1, (wind - 15) / 45) * k) : 0);
    const mote = mk(motes ? Math.round(34 * k) : 0);
    let w = 0, h = 0, raf = 0, last = 0;

    const resize = () => {
      w = window.innerWidth; h = window.innerHeight;
      c.width = Math.round(w * dpr); c.height = Math.round(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener('resize', resize);

    const draw = (dt: number, t: number) => {
      ctx.clearRect(0, 0, w, h);
      // floating light particles (sun motes by day, soft specks at night)
      for (const p of mote) {
        p.x += (dirX * 0.01 * (0.3 + p.z) + Math.sin(t * 0.0004 + p.ph) * 0.004) * dt;
        p.y -= 0.012 * (0.3 + p.z) * dt;
        if (p.y < -0.02) { p.y = 1.02; p.x = Math.random(); }
        if (p.x > 1.02) p.x = -0.02; else if (p.x < -0.02) p.x = 1.02;
        const a = 0.12 + 0.4 * Math.pow(Math.sin(t * 0.0011 + p.ph), 2);
        ctx.fillStyle = dark ? `rgba(190,205,255,${a})` : `rgba(255,190,80,${a})`;
        ctx.beginPath(); ctx.arc(p.x * w, p.y * h, 1 + p.z * 2, 0, 6.283); ctx.fill();
      }
      // wind streaks
      ctx.lineCap = 'round'; ctx.lineWidth = 1.2;
      for (const p of streaks) {
        p.x += dirX * (0.12 + 0.5 * wf) * (0.5 + p.z) * dt;
        if (p.x > 1.3) p.x = -0.3; else if (p.x < -0.3) p.x = 1.3;
        const len = 60 + p.z * 120, x = p.x * w, y = p.y * h, wob = Math.sin(t * 0.0012 + p.ph) * 7;
        ctx.strokeStyle = dark ? `rgba(200,215,255,${0.06 + p.z * 0.12})` : `rgba(70,100,150,${0.07 + p.z * 0.12})`;
        ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x - dirX * len * 0.5, y + wob, x - dirX * len, y); ctx.stroke();
      }
      // rain
      if (rain.length) {
        const slant = dirX * (0.12 + wf * 0.45);
        for (const band of [0, 1]) {
          ctx.strokeStyle = dark ? `rgba(190,210,255,${band ? 0.5 : 0.25})` : `rgba(55,90,145,${band ? 0.5 : 0.28})`;
          ctx.lineWidth = band ? 1.3 : 0.8;
          ctx.beginPath();
          for (const p of rain) {
            if ((p.z > 0.5 ? 1 : 0) !== band) continue;
            const len = 12 + p.z * 20, x = p.x * w, y = p.y * h;
            ctx.moveTo(x, y); ctx.lineTo(x - slant * len, y - len);
          }
          ctx.stroke();
        }
        for (const p of rain) {
          p.y += (0.9 + p.z * 0.7 + p.v * 0.3) * dt;
          p.x += (slant * (0.9 + p.z * 0.7) * dt * h) / w;
          if (p.y > 1.02) { p.y = -0.05; p.x = Math.random() * 1.2 - 0.1; }
        }
      }
      // snow
      for (const p of snow) {
        p.y += (0.03 + p.z * 0.06) * (0.8 + power * 0.6) * dt;
        p.x += (dirX * 0.02 * (0.3 + wf * 2) + Math.sin(t * 0.001 + p.ph) * 0.012) * dt;
        if (p.y > 1.02) { p.y = -0.03; p.x = Math.random(); }
        if (p.x > 1.03) p.x = -0.03; else if (p.x < -0.03) p.x = 1.03;
        const r = 1 + p.z * 2.6;
        ctx.beginPath(); ctx.arc(p.x * w, p.y * h, r, 0, 6.283);
        ctx.fillStyle = `rgba(255,255,255,${0.6 + p.z * 0.35})`; ctx.fill();
        if (!dark) { ctx.strokeStyle = 'rgba(110,140,190,.35)'; ctx.lineWidth = 0.8; ctx.stroke(); }
      }
    };

    const loop = (now: number) => {
      if (!last) last = now;
      const dt = Math.min(0.05, (now - last) / 1000); last = now;
      draw(dt, now);
      raf = requestAnimationFrame(loop);
    };
    const vis = () => { cancelAnimationFrame(raf); if (!document.hidden) { last = 0; raf = requestAnimationFrame(loop); } };
    document.addEventListener('visibilitychange', vis);
    raf = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(raf); window.removeEventListener('resize', resize); document.removeEventListener('visibilitychange', vis); };
  }, [kind, power, wind, windDir, dark, motes, low, reduced]);

  return <canvas ref={ref} className="particles" />;
}
