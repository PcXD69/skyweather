import { cssVars } from '../lib/css';
import { Heart, RefreshCw, Umbrella } from 'lucide-react';
import type { Place, Weather } from '../types';
import { describe } from '../lib/weather';
import { localDateLine, localTime, temp } from '../lib/format';
import { useAnimatedNumber, useNow } from '../hooks/useMisc';
import { useSettings } from '../context/SettingsContext';
import { IconButton } from './ui';
import { WeatherIcon } from './WeatherIcon';

export function Hero({ place, data, fav, onFav, onRefresh, busy, stale }: {
  place: Place; data: Weather; fav: boolean; onFav: () => void; onRefresh: () => void; busy: boolean; stale: boolean;
}) {
  const s = useSettings();
  const now = useNow();
  const c = data.current, cond = describe(c.code), today = data.daily[0];
  const shown = useAnimatedNumber(temp(c.temp, s.temp));
  const region = [place.admin1, place.country].filter(Boolean).join(', ');
  const pop = data.hourly.slice(0, 12).reduce<number | null>((m, h) => (h.pop === null ? m : Math.max(m ?? 0, h.pop)), null);

  return (
    <section className="hero rise" style={cssVars({ '--i': 0 })} aria-label={`Current weather in ${place.name}`}>
      <div className="hero-top">
        <div>
          <h1 className="city">{place.name}</h1>
          <p className="region">{region || 'Current location'}</p>
        </div>
        <div className="hero-actions">
          <IconButton label={fav ? 'Remove from favorites' : 'Add to favorites'} onClick={onFav} active={fav} className={`heart ${fav ? 'is-fav' : ''}`}>
            <Heart size={18} strokeWidth={1.8} fill={fav ? 'currentColor' : 'none'} />
          </IconButton>
          <IconButton label="Refresh" onClick={onRefresh} disabled={busy}><RefreshCw size={18} strokeWidth={1.8} className={busy ? 'spin' : ''} /></IconButton>
        </div>
      </div>

      <p className="clock">{localDateLine(data.tz, now)} <span className="dot" /> {localTime(data.tz, now, s.h24)}{stale && <em className="stale"> · updating</em>}</p>

      <div className="hero-main">
        <div className="temp" role="text" aria-label={`${temp(c.temp, s.temp)} degrees`}>
          <span className="temp-num">{Math.round(shown)}</span><span className="temp-deg">°</span>
        </div>
        <div className="hero-side">
          <WeatherIcon icon={cond.icon} isDay={c.isDay} size={84} stroke={1.15} className="hero-icon" />
          <p className="cond">{cond.label}</p>
        </div>
      </div>

      <ul className="chips">
        <li><span>Feels like</span><b>{temp(c.feels, s.temp)}°</b></li>
        <li><span>High</span><b>{temp(today.max, s.temp)}°</b></li>
        <li><span>Low</span><b>{temp(today.min, s.temp)}°</b></li>
        {pop !== null && <li><Umbrella size={14} strokeWidth={1.8} /><span>Rain chance</span><b>{pop}%</b></li>}
      </ul>
    </section>
  );
}
