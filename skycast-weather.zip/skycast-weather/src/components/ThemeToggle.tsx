import type { Theme } from '../hooks/useTheme';

export function ThemeToggle({ theme, onToggle }: { theme: Theme; onToggle: () => void }) {
  const night = theme === 'dark';
  return (
    <button type="button" role="switch" aria-checked={night} aria-label={night ? 'Switch to day mode' : 'Switch to night mode'}
      className="tt tip" data-tip={night ? 'Day mode' : 'Night mode'} onClick={onToggle}>
      <span className="tt-stars" aria-hidden><i /><i /><i /><i /></span>
      <span className="tt-knob" aria-hidden>
        <svg viewBox="0 0 32 32">
          <defs>
            <mask id="tt-mask"><rect width="32" height="32" fill="#fff" /><circle className="tt-bite" cx="22" cy="12" r="7" fill="#000" /></mask>
          </defs>
          <g className="tt-rays" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            {Array.from({ length: 8 }, (_, i) => <line key={i} x1="16" y1="2.6" x2="16" y2="5.6" transform={`rotate(${i * 45} 16 16)`} />)}
          </g>
          <circle className="tt-disc" cx="16" cy="16" r="8" fill="currentColor" mask="url(#tt-mask)" />
        </svg>
      </span>
    </button>
  );
}
