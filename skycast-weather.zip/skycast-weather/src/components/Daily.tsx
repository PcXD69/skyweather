import { cssVars } from '../lib/css';
import { CalendarDays, Droplets } from 'lucide-react';
import type { Weather } from '../types';
import { describe } from '../lib/weather';
import { dayDate, dayName, temp } from '../lib/format';
import { useSettings } from '../context/SettingsContext';
import { WeatherIcon } from './WeatherIcon';

export function Daily({ data }: { data: Weather }) {
  const s = useSettings();
  const lo = Math.min(...data.daily.map(d => d.min)), hi = Math.max(...data.daily.map(d => d.max)), span = Math.max(1, hi - lo);
  const nowT = data.current.temp;
  return (
    <section className="card glass rise" style={cssVars({ '--i': 2 })} aria-labelledby="daily-h">
      <h2 className="card-h" id="daily-h"><CalendarDays size={16} strokeWidth={1.8} /> 7-day forecast</h2>
      <ul className="daily">
        {data.daily.map((d, i) => {
          const cond = describe(d.code), l = ((d.min - lo) / span) * 100, w = ((d.max - d.min) / span) * 100;
          return (
            <li key={d.date} className="drow">
              <div className="d-day"><b>{i === 0 ? 'Today' : dayName(d.date)}</b><small>{dayDate(d.date)}</small></div>
              <div className="d-cond"><WeatherIcon icon={cond.icon} isDay size={24} /><span>{cond.label}</span></div>
              <span className="d-pop"><Droplets size={12} strokeWidth={1.8} />{d.pop ?? '–'}{d.pop !== null && '%'}</span>
              <span className="d-min">{temp(d.min, s.temp)}°</span>
              <div className="range" aria-hidden>
                <i style={{ left: `${l}%`, width: `${Math.max(w, 6)}%`, animationDelay: `${200 + i * 70}ms` }} />
                {i === 0 && <u style={{ left: `${Math.min(98, Math.max(2, ((nowT - lo) / span) * 100))}%` }} />}
              </div>
              <span className="d-max">{temp(d.max, s.temp)}°</span>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
