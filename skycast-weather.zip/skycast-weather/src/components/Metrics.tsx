import { cssVars } from '../lib/css';
import type { ReactNode } from 'react';
import { Droplets, Eye, Gauge, Leaf, Sun, Sunrise, Sunset, Wind } from 'lucide-react';
import type { Weather } from '../types';
import { aqiLabel, pressureLabel, uvLabel } from '../lib/weather';
import { cardinal, distance, minutesOf, pressure, speed, speedUnit, timeOfIso } from '../lib/format';
import { useSettings } from '../context/SettingsContext';

function Tile({ icon, title, children, wide, i }: { icon: ReactNode; title: string; children: ReactNode; wide?: boolean; i: number }) {
  return <article className={`tile glass rise ${wide ? 'wide' : ''}`} style={cssVars({ '--i': 3 + i * 0.5 })}><h3>{icon}{title}</h3>{children}</article>;
}
const Bar = ({ p, grad }: { p: number; grad?: boolean }) => <div className={`mbar ${grad ? 'grad' : ''}`}><i style={{ width: `${Math.min(100, Math.max(2, p))}%` }} /></div>;

function SunArc({ data }: { data: Weather }) {
  const s = useSettings();
  const d = data.daily[0], a = minutesOf(d.sunrise), b = minutesOf(d.sunset), n = minutesOf(data.current.time);
  const p = Math.min(1, Math.max(0, (n - a) / (b - a))), up = n >= a && n <= b;
  const x = (1 - p) * (1 - p) * 16 + 2 * (1 - p) * p * 110 + p * p * 204, y = (1 - p) * (1 - p) * 84 + 2 * (1 - p) * p * -34 + p * p * 84;
  return (
    <div className="sunarc">
      <svg viewBox="0 0 220 96" role="img" aria-label={`Sunrise ${timeOfIso(d.sunrise, s.h24)}, sunset ${timeOfIso(d.sunset, s.h24)}`}>
        <path d="M16 84Q110 -34 204 84" className="arc-bg" />
        <path d="M16 84Q110 -34 204 84" className="arc-fg" pathLength={1} strokeDasharray={`${p} 1`} />
        <line x1="6" y1="84" x2="214" y2="84" className="horizon" />
        <circle cx={x} cy={y} r="7" className={`arc-dot ${up ? '' : 'off'}`} />
      </svg>
      <div className="sun-times">
        <span><Sunrise size={15} strokeWidth={1.8} /> {timeOfIso(d.sunrise, s.h24)}</span>
        <span><Sunset size={15} strokeWidth={1.8} /> {timeOfIso(d.sunset, s.h24)}</span>
      </div>
    </div>
  );
}

export function Metrics({ data }: { data: Weather }) {
  const s = useSettings(), c = data.current;
  const uv = c.uv ?? data.daily[0].uv;
  const aqi = data.aqi?.us ?? null;
  return (
    <div className="metrics">
      <Tile i={0} wide icon={<Sunrise size={15} strokeWidth={1.8} />} title="Sunrise & sunset"><SunArc data={data} /></Tile>
      <Tile i={1} icon={<Wind size={15} strokeWidth={1.8} />} title="Wind">
        <div className="wind">
          <svg viewBox="0 0 80 80" aria-hidden><circle cx="40" cy="40" r="34" className="compass" />
            {['N', 'E', 'S', 'W'].map((t, k) => <text key={t} x={40 + Math.sin((k * Math.PI) / 2) * 27} y={40 - Math.cos((k * Math.PI) / 2) * 27 + 3} textAnchor="middle">{t}</text>)}
            <g className="needle" style={{ transform: `rotate(${c.windDir + 180}deg)` }}><path d="M40 16 46 40H34z" /></g></svg>
          <div><p className="big">{speed(c.windSpeed, s.wind)}<small> {speedUnit[s.wind]}</small></p><p className="sub">From {cardinal(c.windDir)}{c.gust !== null && ` · gusts ${speed(c.gust, s.wind)} ${speedUnit[s.wind]}`}</p></div>
        </div>
      </Tile>
      <Tile i={2} icon={<Droplets size={15} strokeWidth={1.8} />} title="Humidity">
        <p className="big">{Math.round(c.humidity)}<small>%</small></p><Bar p={c.humidity} /><p className="sub">{c.humidity > 70 ? 'Humid' : c.humidity < 30 ? 'Dry' : 'Comfortable'}</p>
      </Tile>
      <Tile i={3} icon={<Sun size={15} strokeWidth={1.8} />} title="UV index">
        {uv === null ? <p className="sub">No data</p> : <><p className="big">{Math.round(uv)}<small> {uvLabel(uv)}</small></p><Bar grad p={(uv / 11) * 100} /></>}
      </Tile>
      <Tile i={4} icon={<Eye size={15} strokeWidth={1.8} />} title="Visibility">
        {c.visibility === null ? <p className="sub">No data</p> : <><p className="big">{distance(c.visibility, s.wind).split(' ')[0]}<small> {distance(c.visibility, s.wind).split(' ')[1]}</small></p><p className="sub">{c.visibility >= 10000 ? 'Clear view' : c.visibility >= 4000 ? 'Reduced' : 'Poor'}</p></>}
      </Tile>
      <Tile i={5} icon={<Gauge size={15} strokeWidth={1.8} />} title="Pressure">
        <p className="big">{pressure(c.pressure, s.pressure)}<small> {s.pressure === 'hpa' ? 'hPa' : 'inHg'}</small></p><p className="sub">{pressureLabel(c.pressure)}</p>
      </Tile>
      <Tile i={6} icon={<Leaf size={15} strokeWidth={1.8} />} title="Air quality">
        {aqi === null ? <p className="sub">Not available here</p> : <><p className="big">{Math.round(aqi)}<small> US AQI</small></p><Bar grad p={(aqi / 200) * 100} /><p className="sub">{aqiLabel(aqi)}</p></>}
      </Tile>
    </div>
  );
}
