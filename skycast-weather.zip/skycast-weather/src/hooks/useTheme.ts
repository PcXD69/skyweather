import { useCallback, useEffect, useState } from 'react';

export type Theme = 'light' | 'dark';
const KEY = 'wx.theme';

function initial(): Theme {
  try {
    const s = JSON.parse(localStorage.getItem(KEY) ?? 'null');
    if (s === 'light' || s === 'dark') return s;
  } catch { /* ignore */ }
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

export function useTheme() {
  const [theme, setThemeState] = useState<Theme>(initial);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', theme === 'dark' ? '#05070f' : '#fbf7ef');
  }, [theme]);

  // Follow the system until the person picks a theme themselves.
  useEffect(() => {
    if (localStorage.getItem(KEY)) return;
    const m = window.matchMedia('(prefers-color-scheme: dark)');
    const on = () => { if (!localStorage.getItem(KEY)) setThemeState(m.matches ? 'dark' : 'light'); };
    m.addEventListener('change', on);
    return () => m.removeEventListener('change', on);
  }, []);

  const setTheme = useCallback((t: Theme, persist = true) => {
    setThemeState(t);
    if (persist) { try { localStorage.setItem(KEY, JSON.stringify(t)); } catch { /* ignore */ } }
  }, []);
  const toggle = useCallback(() => setTheme(theme === 'dark' ? 'light' : 'dark'), [theme, setTheme]);
  return { theme, toggle, setTheme };
}
