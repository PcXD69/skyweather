import type { Settings } from '../types';

const pad = (n: number) => String(n).padStart(2, '0');
export const cToF = (c: number) => (c * 9) / 5 + 32;
export const temp = (c: number, u: Settings['temp']) => Math.round(u === 'f' ? cToF(c) : c);
export const speed = (kmh: number, u: Settings['wind']) =>
  Math.round(u === 'mph' ? kmh * 0.621371 : u === 'ms' ? kmh / 3.6 : u === 'kn' ? kmh * 0.539957 : kmh);
export const speedUnit: Record<Settings['wind'], string> = { kmh: 'km/h', mph: 'mph', ms: 'm/s', kn: 'kn' };
export const pressure = (h: number, u: Settings['pressure']) => (u === 'inhg' ? (h * 0.02953).toFixed(2) : String(Math.round(h)));
export const distance = (m: number, u: Settings['wind']) =>
  u === 'mph' ? `${(m / 1609.34).toFixed(m > 16000 ? 0 : 1)} mi` : `${(m / 1000).toFixed(m >= 10000 ? 0 : 1)} km`;

const CARD = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'];
export const cardinal = (d: number) => CARD[Math.round(d / 22.5) % 16];

export const hourLabel = (iso: string, h24: boolean) => {
  const h = +iso.slice(11, 13);
  return h24 ? `${pad(h)}:00` : `${h % 12 || 12} ${h < 12 ? 'AM' : 'PM'}`;
};
export const timeOfIso = (iso: string, h24: boolean) => {
  const h = +iso.slice(11, 13), m = iso.slice(14, 16);
  return h24 ? `${pad(h)}:${m}` : `${h % 12 || 12}:${m} ${h < 12 ? 'AM' : 'PM'}`;
};
const utcDate = (d: string) => { const [y, m, dd] = d.split('-').map(Number); return new Date(Date.UTC(y, m - 1, dd)); };
export const dayName = (d: string) => new Intl.DateTimeFormat(undefined, { weekday: 'short', timeZone: 'UTC' }).format(utcDate(d));
export const dayDate = (d: string) => new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric', timeZone: 'UTC' }).format(utcDate(d));
export const minutesOf = (iso: string) =>
  Date.UTC(+iso.slice(0, 4), +iso.slice(5, 7) - 1, +iso.slice(8, 10), +iso.slice(11, 13), +iso.slice(14, 16)) / 6e4;

export const localDateLine = (tz: string, now: Date) =>
  new Intl.DateTimeFormat(undefined, { weekday: 'long', month: 'long', day: 'numeric', timeZone: tz }).format(now);
export const localTime = (tz: string, now: Date, h24: boolean) =>
  new Intl.DateTimeFormat(undefined, { hour: h24 ? '2-digit' : 'numeric', minute: '2-digit', hour12: !h24, timeZone: tz }).format(now);
