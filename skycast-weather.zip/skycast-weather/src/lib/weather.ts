import type { Cond, IconKey, Sky } from '../types';

type Row = [string, Sky, number, 'none' | 'rain' | 'snow', number, 0 | 1 | 2, IconKey];

// WMO weather interpretation codes (Open-Meteo) → label + scene parameters
const T: Record<number, Row> = {
  0: ['Clear sky', 'clear', 0, 'none', 0, 0, 'clear'],
  1: ['Mainly clear', 'clear', 1, 'none', 0, 0, 'clear'],
  2: ['Partly cloudy', 'partly', 3, 'none', 0, 0, 'partly'],
  3: ['Overcast', 'cloudy', 7, 'none', 0, 1, 'cloudy'],
  45: ['Fog', 'fog', 3, 'none', 0, 1, 'fog'],
  48: ['Rime fog', 'fog', 3, 'none', 0, 1, 'fog'],
  51: ['Light drizzle', 'rain', 5, 'rain', 0.25, 1, 'drizzle'],
  53: ['Drizzle', 'rain', 5, 'rain', 0.35, 1, 'drizzle'],
  55: ['Dense drizzle', 'rain', 6, 'rain', 0.5, 1, 'drizzle'],
  56: ['Freezing drizzle', 'rain', 5, 'rain', 0.35, 1, 'drizzle'],
  57: ['Heavy freezing drizzle', 'rain', 6, 'rain', 0.5, 1, 'drizzle'],
  61: ['Light rain', 'rain', 6, 'rain', 0.45, 1, 'rain'],
  63: ['Rain', 'rain', 7, 'rain', 0.7, 1, 'rain'],
  65: ['Heavy rain', 'rain', 9, 'rain', 1, 2, 'rain'],
  66: ['Freezing rain', 'rain', 7, 'rain', 0.6, 1, 'rain'],
  67: ['Heavy freezing rain', 'rain', 9, 'rain', 0.9, 2, 'rain'],
  71: ['Light snow', 'snow', 5, 'snow', 0.4, 0, 'snow'],
  73: ['Snow', 'snow', 6, 'snow', 0.65, 1, 'snow'],
  75: ['Heavy snow', 'snow', 7, 'snow', 0.95, 1, 'snow'],
  77: ['Snow grains', 'snow', 5, 'snow', 0.3, 0, 'snow'],
  80: ['Rain showers', 'rain', 6, 'rain', 0.5, 1, 'rain'],
  81: ['Heavy showers', 'rain', 7, 'rain', 0.75, 1, 'rain'],
  82: ['Violent showers', 'rain', 9, 'rain', 1, 2, 'rain'],
  85: ['Snow showers', 'snow', 5, 'snow', 0.5, 0, 'snow'],
  86: ['Heavy snow showers', 'snow', 7, 'snow', 0.9, 1, 'snow'],
  95: ['Thunderstorm', 'storm', 9, 'rain', 0.75, 2, 'storm'],
  96: ['Thunderstorm with hail', 'storm', 9, 'rain', 0.9, 2, 'storm'],
  99: ['Severe thunderstorm', 'storm', 10, 'rain', 1, 2, 'storm'],
};

export function describe(code: number): Cond {
  const r = T[code] ?? T[0];
  return { label: r[0], sky: r[1], clouds: r[2], precip: r[3], power: r[4], tone: r[5], icon: r[6] };
}

export const uvLabel = (v: number) => (v < 3 ? 'Low' : v < 6 ? 'Moderate' : v < 8 ? 'High' : v < 11 ? 'Very high' : 'Extreme');
export const aqiLabel = (v: number) =>
  v <= 50 ? 'Good' : v <= 100 ? 'Moderate' : v <= 150 ? 'Unhealthy for some' : v <= 200 ? 'Unhealthy' : v <= 300 ? 'Very unhealthy' : 'Hazardous';
export const pressureLabel = (h: number) => (h < 1009 ? 'Low' : h > 1022 ? 'High' : 'Steady');
