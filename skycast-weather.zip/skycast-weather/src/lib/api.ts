import type { Place, Weather } from '../types';

const GEO = 'https://geocoding-api.open-meteo.com/v1/search';
const FORECAST = 'https://api.open-meteo.com/v1/forecast';
const AIR = 'https://air-quality-api.open-meteo.com/v1/air-quality';
const TTL = 10 * 60 * 1000;

async function getJSON<T>(url: string, signal?: AbortSignal): Promise<T> {
  const res = await fetch(url, { signal });
  if (!res.ok) throw new Error(`Weather service returned ${res.status}`);
  return (await res.json()) as T;
}
const num = (v: unknown): number | null => (typeof v === 'number' && Number.isFinite(v) ? v : null);

export const placeId = (lat: number, lon: number) => `${lat.toFixed(2)},${lon.toFixed(2)}`;

const searchCache = new Map<string, Place[]>();
export async function searchPlaces(query: string, signal?: AbortSignal): Promise<Place[]> {
  const q = query.trim().toLowerCase();
  const hit = searchCache.get(q);
  if (hit) return hit;
  const lang = (document.documentElement.lang || 'en').slice(0, 2);
  const j = await getJSON<any>(`${GEO}?name=${encodeURIComponent(query.trim())}&count=8&language=${lang}&format=json`, signal);
  const out: Place[] = (j.results ?? []).map((r: any) => ({
    id: placeId(r.latitude, r.longitude), name: r.name, admin1: r.admin1, country: r.country,
    cc: r.country_code, lat: r.latitude, lon: r.longitude, tz: r.timezone,
  }));
  searchCache.set(q, out);
  return out;
}

/** Name a coordinate (browser geolocation). Falls back gracefully if the lookup fails. */
export async function nameCoordinates(lat: number, lon: number, signal?: AbortSignal): Promise<Place> {
  const base: Place = { id: placeId(lat, lon), name: 'Current location', lat, lon };
  try {
    const j = await getJSON<any>(
      `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat}&longitude=${lon}&localityLanguage=en`, signal);
    const name = j.city || j.locality || j.principalSubdivision;
    if (name) return { ...base, name, admin1: j.principalSubdivision || undefined, country: j.countryName || undefined, cc: j.countryCode || undefined };
  } catch { /* keep fallback */ }
  return base;
}

function parse(f: any, aq: any): Weather {
  const c = f.current;
  const hi = Math.max(0, f.hourly.time.indexOf(String(c.time).slice(0, 13) + ':00'));
  const h = f.hourly;
  const hourly = h.time.slice(hi, hi + 25).map((t: string, k: number) => ({
    time: t, temp: h.temperature_2m[hi + k], code: h.weather_code[hi + k] ?? 0,
    isDay: h.is_day[hi + k] === 1, pop: num(h.precipitation_probability[hi + k]),
  }));
  const d = f.daily;
  const daily = d.time.map((date: string, k: number) => ({
    date, code: d.weather_code[k] ?? 0, min: d.temperature_2m_min[k], max: d.temperature_2m_max[k],
    pop: num(d.precipitation_probability_max[k]), sunrise: d.sunrise[k], sunset: d.sunset[k], uv: num(d.uv_index_max[k]),
  }));
  return {
    fetchedAt: Date.now(), tz: f.timezone,
    current: {
      time: c.time, temp: c.temperature_2m, feels: c.apparent_temperature ?? c.temperature_2m,
      humidity: c.relative_humidity_2m, code: c.weather_code ?? 0, isDay: c.is_day === 1,
      pressure: c.pressure_msl, windSpeed: c.wind_speed_10m, windDir: c.wind_direction_10m,
      gust: num(c.wind_gusts_10m), precip: c.precipitation ?? 0,
      visibility: num(h.visibility?.[hi]), uv: num(h.uv_index?.[hi]),
    },
    hourly, daily,
    aqi: aq?.current ? { us: num(aq.current.us_aqi), pm25: num(aq.current.pm2_5) } : null,
  };
}

const cacheKey = (p: Place) => `wx.cache.${p.id}`;
export function readCache(p: Place): Weather | null {
  try { const raw = localStorage.getItem(cacheKey(p)); return raw ? (JSON.parse(raw) as Weather) : null; } catch { return null; }
}
export const isFresh = (w: Weather | null, ms = TTL) => !!w && Date.now() - w.fetchedAt < ms;

export async function fetchWeather(p: Place, signal?: AbortSignal): Promise<Weather> {
  const q = `latitude=${p.lat}&longitude=${p.lon}&timezone=auto&forecast_days=7`;
  const fUrl = `${FORECAST}?${q}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,pressure_msl,wind_speed_10m,wind_direction_10m,wind_gusts_10m` +
    `&hourly=temperature_2m,precipitation_probability,weather_code,is_day,visibility,uv_index` +
    `&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_probability_max`;
  const aUrl = `${AIR}?latitude=${p.lat}&longitude=${p.lon}&current=us_aqi,pm2_5`;
  const [f, aq] = await Promise.all([getJSON<any>(fUrl, signal), getJSON<any>(aUrl, signal).catch(() => null)]);
  const w = parse(f, aq);
  try { localStorage.setItem(cacheKey(p), JSON.stringify(w)); } catch { /* storage full */ }
  return w;
}
