export interface Place {
  id: string;
  name: string;
  admin1?: string;
  country?: string;
  cc?: string;
  lat: number;
  lon: number;
  tz?: string;
}

export type Sky = 'clear' | 'partly' | 'cloudy' | 'fog' | 'rain' | 'storm' | 'snow';
export type IconKey = 'clear' | 'partly' | 'cloudy' | 'fog' | 'drizzle' | 'rain' | 'snow' | 'storm';

export interface Cond {
  label: string;
  sky: Sky;
  clouds: number;
  precip: 'none' | 'rain' | 'snow';
  power: number;
  tone: 0 | 1 | 2;
  icon: IconKey;
}

export interface HourPoint { time: string; temp: number; code: number; isDay: boolean; pop: number | null }
export interface DayPoint {
  date: string; code: number; min: number; max: number;
  pop: number | null; sunrise: string; sunset: string; uv: number | null;
}
export interface Weather {
  fetchedAt: number;
  tz: string;
  current: {
    time: string; temp: number; feels: number; humidity: number; code: number; isDay: boolean;
    pressure: number; windSpeed: number; windDir: number; gust: number | null; precip: number;
    visibility: number | null; uv: number | null;
  };
  hourly: HourPoint[];
  daily: DayPoint[];
  aqi: { us: number | null; pm25: number | null } | null;
}

export interface Settings {
  temp: 'c' | 'f';
  wind: 'kmh' | 'mph' | 'ms' | 'kn';
  pressure: 'hpa' | 'inhg';
  h24: boolean;
  refresh: number; // minutes, 0 = off
  autoTheme: boolean;
  effects: 'full' | 'low';
}
