// Runs in CI after `npx cap add android` + `npx cap sync android`.
// 1) Builds one APK per CPU architecture (+ a universal APK).
// 2) Adds the location permissions needed by "Use my current location".
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';

const root = process.env.ANDROID_DIR || 'android';
const gradle = join(root, 'app', 'build.gradle');
const manifest = join(root, 'app', 'src', 'main', 'AndroidManifest.xml');
for (const f of [gradle, manifest]) if (!existsSync(f)) { console.error('Missing ' + f); process.exit(1); }

let g = readFileSync(gradle, 'utf8');
if (!g.includes('universalApk')) {
  const splits = `    splits {
        abi {
            enable true
            reset()
            include 'armeabi-v7a', 'arm64-v8a', 'x86', 'x86_64'
            universalApk true
        }
    }

`;
  if (!/^\s*buildTypes\s*\{/m.test(g)) { console.error('buildTypes block not found in build.gradle'); process.exit(1); }
  g = g.replace(/^(\s*)buildTypes\s*\{/m, (m) => splits + m);
  writeFileSync(gradle, g);
  console.log('Added ABI splits to build.gradle');
}

let m = readFileSync(manifest, 'utf8');
const perms = ['ACCESS_COARSE_LOCATION', 'ACCESS_FINE_LOCATION'];
for (const p of perms) {
  if (!m.includes(`android.permission.${p}`)) {
    m = m.replace('</manifest>', `    <uses-permission android:name="android.permission.${p}" />\n</manifest>`);
  }
}
if (!m.includes('android.permission.INTERNET')) m = m.replace('</manifest>', '    <uses-permission android:name="android.permission.INTERNET" />\n</manifest>');
writeFileSync(manifest, m);
console.log('Manifest permissions ready');
