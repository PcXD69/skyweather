# SkyCast — premium real-time weather app

A polished weather app for **any city in the world**, built with React, TypeScript and Vite.
Real data from [Open-Meteo](https://open-meteo.com/) (no API key, no secrets), cinematic day/night theme, animated weather scenes, and one-click GitHub Pages deployment.

## Features

- Worldwide city search with live suggestions, region/country labels and coordinates (cities with the same name are easy to tell apart).
- Browser geolocation ("Use my current location"), favorites, recent searches.
- Current conditions: temperature, feels-like, high/low, humidity, wind speed + direction, visibility, UV, pressure, air quality, sunrise/sunset arc.
- 24-hour scrollable forecast and 7-day forecast with animated temperature range bars.
- Animated **sun ⇄ moon** theme toggle. Cinematic background cross-fade, twinkling stars, glowing sun and moon. Saved in `localStorage`; the system theme is used on the first visit. Optional "Follow local daylight".
- Weather scenes: sun with rays, drifting clouds (several depths), rain, heavy rain, thunderstorm with lightning, snow, fog, wind streaks, clear/partly-cloudy night. Intensity follows the real weather code.
- Settings: °C/°F, km/h · mph · m/s · kn, hPa/inHg, 12/24 h, auto-refresh interval, light visual effects mode.
- Caching (10 min), automatic refresh, offline-tolerant (shows the last data), skeleton loaders, toasts, accessible modals, `prefers-reduced-motion` support.

## Tech

React 18 · TypeScript · Vite 5 · lucide-react (only runtime dependency besides React) · plain modular CSS · Open-Meteo APIs (forecast, geocoding, air quality).
Geolocation names come from BigDataCloud's free client reverse-geocoding endpoint (optional; falls back to "Current location").

## Project structure

```
.github/workflows/deploy.yml   GitHub Pages workflow
public/favicon.svg
src/
  main.tsx, App.tsx, types.ts
  lib/        api.ts (Open-Meteo + cache), weather.ts (WMO codes), format.ts, css.ts
  hooks/      useWeather, useTheme, useMisc (storage, reduced motion, animated number)
  context/    SettingsContext, Toast
  components/ Atmosphere, Particles, Header, ThemeToggle, Hero, Hourly, Daily,
              Metrics, SearchModal, SettingsModal, Modal, States, WeatherIcon, ui
  styles/     tokens.css, base.css, atmosphere.css, components.css
vite.config.ts, tsconfig.json, index.html, package.json
```

## Run locally

Requires Node.js 18 or newer.

```bash
npm install          # creates package-lock.json (commit it!)
npm run dev          # http://localhost:5173
npm run build        # production build in ./dist
npm run preview      # preview the production build
npm run typecheck    # optional strict TypeScript check
```

## Deploy to GitHub Pages (step by step)

1. **Create a repository** on GitHub (public is simplest; any name). Do *not* add a README there.
2. **Upload the files.** Unzip the archive and upload the *contents* (not the outer folder) so `package.json` is at the repository root.
   - Easiest and safest: use Git:
     ```bash
     cd skycast-weather
     git init && git add . && git commit -m "Initial commit"
     git branch -M main
     git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO.git
     git push -u origin main
     ```
   - Using the website's drag-and-drop? Hidden folders such as `.github` are often skipped by Finder/Explorer. After uploading, check that `.github/workflows/deploy.yml` exists; if not, click **Add file → Create new file**, type `.github/workflows/deploy.yml` as the name and paste the file's content.
3. **Enable Pages with GitHub Actions:** repository → **Settings → Pages → Build and deployment → Source: GitHub Actions**.
4. **Allow workflows:** **Settings → Actions → General** → *Allow all actions and reusable workflows* and, under *Workflow permissions*, either option is fine (the workflow requests what it needs).
5. **Run it:** every push to `main` deploys automatically. You can also open the **Actions** tab → *Deploy to GitHub Pages* → **Run workflow**.
6. **Open your app:** when the run is green, the deploy job shows the URL, also under **Settings → Pages**. Typically `https://YOUR-USERNAME.github.io/YOUR-REPO/`.

### Repository name / base path

`vite.config.ts` uses `base: './'` (relative paths), so the app works under **any** repository name, on `username.github.io`, and on custom domains — you do not need to edit anything. The app has no client-side routing, so there are no 404 problems on refresh.
If you ever prefer an absolute base, change it to `base: '/YOUR-REPO/'` (both slashes) or set the `VITE_BASE` environment variable in the workflow's *Build* step.

## Troubleshooting

| Problem | Fix |
| --- | --- |
| `Get Pages site failed` / `Not Found` in *Configure Pages* | Pages is not enabled. Settings → Pages → Source: **GitHub Actions**, then re-run. |
| Workflow does not start | The file must be exactly `.github/workflows/deploy.yml` on the `main` branch (not `master`; rename your branch or edit the `branches:` line). |
| `npm ci` fails ("lock file out of sync") | Run `npm install` locally and commit the updated `package-lock.json`, or delete the lock file and let the workflow use `npm install`. |
| Deploy job: "Branch is not allowed to deploy" | Settings → Environments → github-pages → allow the `main` branch. |
| Blank page / 404 for JS and CSS | Keep `base: './'` in `vite.config.ts`, or make sure an absolute base matches the repository name exactly. |
| Private repository cannot publish | GitHub Pages on private repos requires a paid plan. Make the repo public. |
| Weather does not load | Check your connection; Open-Meteo must be reachable. The app shows the last cached data when possible. |

## Credits & license

Weather data by [Open-Meteo.com](https://open-meteo.com/) (CC BY 4.0). Attribution is shown in the app footer.

## Android APK (built automatically on GitHub)

The app is wrapped with [Capacitor](https://capacitorjs.com/) and a second workflow, `.github/workflows/build-apk.yml`, builds the APKs in the cloud — you do not need Android Studio.

**Run it:** repository → **Actions** → *Build Android APKs* → **Run workflow**. After about 5–10 minutes, open the finished run and download the `skycast-apks` artifact (a ZIP). It contains:

| File | Devices |
| --- | --- |
| `SkyCast-arm64-v8a.apk` | Almost all phones and tablets from 2017 onwards (**choose this one first**) |
| `SkyCast-armeabi-v7a.apk` | Older 32-bit ARM phones |
| `SkyCast-x86_64.apk` / `SkyCast-x86.apk` | Emulators, Chromebooks, some Intel tablets |
| `SkyCast-universal.apk` | Works everywhere (larger file) |

Not sure which one? Install the **universal** APK.

**Release page:** push a tag such as `git tag v1.0.0 && git push origin v1.0.0` and the APKs are also attached to a GitHub Release with direct download links.

**Installing:** copy the APK to the phone, open it, and allow "Install unknown apps" when asked. These are debug-signed builds, ideal for sideloading and testing. Publishing on Google Play needs a release-signed AAB with your own keystore (not included).

**Notes:** the first run creates the `android/` project automatically (`npx cap add android`). The workflow adds per-CPU splits and location permissions through `scripts/patch-android.mjs`. To customize the app icon, replace the images in `android/app/src/main/res/mipmap-*` after generating the project locally (`npx cap add android`) and commit the `android/` folder.
